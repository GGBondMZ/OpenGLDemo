/*
 *
 * Renderer.java
 * 
 * Created by Wuwang on 2017/3/3
 * Copyright © 2016年 深圳哎吖科技. All rights reserved.
 */
package edu.wuwang.opengl.camera;

import android.opengl.GLSurfaceView;

/**
 * Description:
 */
public interface Renderer extends GLSurfaceView.Renderer {

    void onDestroy();

}
